function initMap() {
  const office = {lat: 45.48561441183174, lng: -122.80675717315412};

  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 18,
    center: office,
  });

  const marker = new google.maps.Marker({
    position: office,
    map: map,
  });
}

$(function () {
    var $testimonials = $("#testimonials");
    var testimonials = ['I', 'Am', 'So', 'Cool'];
    var position = -1;

    !function loop() {
        position = (position + 1) % testimonials.length;
        $testimonials.html(testimonials[position])
        .fadeIn(1000)
        .delay(1000)
        .fadeOut(1000, loop);
    }();
});
