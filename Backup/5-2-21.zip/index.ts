function initMap(): void {
  const office = {lat: 45.48561441183174, lng: -122.80675717315412};

  const map = new google.maps.Map(
    document.getElementById("map") as HTMLElement,
    {
      zoom: 18,
      center: office,
    }
  );

  const marker = new google.maps.Marker({
    position: office,
    map: map,
  });
}
